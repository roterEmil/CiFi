This zipfile contains source code corresponding to the
Checker Framework tutorial:
http://types.cs.washington.edu/checker-framework/tutorial/
